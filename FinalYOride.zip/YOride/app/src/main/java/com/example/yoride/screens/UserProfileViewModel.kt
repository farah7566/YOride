package com.example.yoride.screens

class UserProfileViewModel {

}
